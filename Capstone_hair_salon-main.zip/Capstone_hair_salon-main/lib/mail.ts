import "dotenv/config";
import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: process.env.SERVICE, //gmail
  auth: {
    user: process.env.USER, // Google email address
    pass: process.env.PASSWORD, // Google app password
  },
});

/**
 * Getting google app password:
 * 1. Go to your google account settings
 * 2. Search for App Passwords
 * 3. Set app name and generate a new app password
 */

interface MailOptions {
  from: string;
  to: string[];
  cc: string[];
  subject: string;
  html: string;
}

export function sendMail(
  from: string,
  to: string[],
  cc: string[],
  subject: string,
  html: string,
  callback: (e: any) => void
): void {
  const mailOptions: MailOptions = {
    from: from, // sender address
    to: to, // list of receivers
    cc: cc,
    subject: subject, // Subject line
    html: html, // plain text body
  };
  transporter.sendMail(mailOptions, function (err: any, info: any) {
    if (err) console.log(err);
    else callback(info);
  });
}

/**
 * sendMail() function takes 5 parameters:
 * 1. from: Sender's email address, string
 * 2. to: Receiver's email address, an array of recipients email addresses that will appear on the To: field
 * 3. subject: Email subject, an array of recipients email addresses that will appear on the Cc: field
 * 4. html: Email body, html
 * 5. callback: A function that takes one parameter, info, which is the response from successfull sending of the email
 * Any error resulting from sending the email will be logged to the console
 * Example usage:
 * sendMail(
        "from@gmail.com",
        ["to@gmail.com"],
        ["cc@gmail.com"], // can be empty
        "Test Header",
        "<h1>Test email body</h1>",
        back
    );

    function back(response) {
        console.log(response);
    }

 */
