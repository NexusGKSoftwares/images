interface AppointmentSlot {
    start: Date;
    end: Date;
}