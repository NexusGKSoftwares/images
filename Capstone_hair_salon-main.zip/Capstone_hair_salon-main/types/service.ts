export interface Service {
    id: string;
    name: string;
    duration: number;
    cost: number;
}